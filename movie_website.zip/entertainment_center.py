# Lesson 3.4: Make Classes
# Mini-Project: Movies Website

### Load modules ###
import media
import fresh_tomatoes

### Create instance of class Movie for each movie ###

the_shining = media.Movie("The Shining", "A writer goes crazy and tries to kill his family",
                           "http://t0.gstatic.com/images?q=tbn:ANd9GcSurv36gKqz9FhNhK8-ziym4RxX5bbVwvk_V-u_TvdI4T-omHXt",
                           "https://www.youtube.com/watch?v=1G7Ju035-8U","Jack Nicholson and Shelley Duvall","R")

the_strangers = media.Movie("The Strangers","A couple tries to survive a killer gang",
                            "https://upload.wikimedia.org/wikipedia/en/4/4a/Strangersposter.jpg",
                            "https://www.youtube.com/watch?v=P8O5Vd2VxDM","Liv Tyler and Scott Speedman","R")

blade = media.Movie("Blade","A Daywalker fights vampires",
                    "https://upload.wikimedia.org/wikipedia/en/1/19/Blade_movie.jpg",
                    "https://www.youtube.com/watch?v=kaU2A7KyOu4","Wesley Snipes and Stephen Dorff","R")

project_x = media.Movie("Project X","Three frieds throw the best party in the world",
                        "https://upload.wikimedia.org/wikipedia/en/b/b4/Project_X_Poster.jpg",
                        "https://www.youtube.com/watch?v=c2fsYheE1yY","Thomas Mann and Oliver Cooper","R")

dumb_and_dumber = media.Movie("Dumb and Dumber","Two best friends take a trip to Colorado",
                              "https://upload.wikimedia.org/wikipedia/en/6/64/Dumbanddumber.jpg",
                              "https://www.youtube.com/watch?v=l13yPhimE3o","Jim Carrey and Jeff Daniels","PG-13")

underworld = media.Movie("Underworld","Conflict and war between Vampires and Lycans",
                         "https://upload.wikimedia.org/wikipedia/en/d/da/Underworld_poster.jpg",
                         "https://www.youtube.com/watch?v=RuoIQySqmMQ","Kate Beckinsale and Scott Speedman","R")


### Create a list of the movies ###
movies = [the_shining, the_strangers, blade, project_x, dumb_and_dumber, underworld]

### Creates the web page with the list of movies ###
fresh_tomatoes.open_movies_page(movies)


